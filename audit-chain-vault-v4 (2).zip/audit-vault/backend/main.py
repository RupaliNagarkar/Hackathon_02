"""
Audit Chain Evidence Vault — Backend API v4
Changes:
  - Gemini key + URL fully server-side; frontend calls /api/ai/query
  - ServiceNow spoof agent at /api/servicenow/*
  - DELETE /api/docs/delete
  - GET  /api/docs/download-all/{app_id}  → ZIP of all docs for that app
"""

from fastapi import FastAPI, HTTPException, Depends, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel
from typing import Optional
import uuid, json, logging, os, shutil, io, zipfile
from datetime import datetime
from pathlib import Path

from agents.master_agent    import MasterAgent
from agents.search_agent    import SearchAgent
from agents.evidence_agent  import EvidenceAgent
from agents.exception_agent import ExceptionAgent
from agents.servicenow_agent import ServiceNowAgent
from vector_db.vault        import EvidenceVault
from auth                   import authenticate_user, create_token, verify_token

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Audit Chain Evidence Vault v4", version="4.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])
security = HTTPBearer()

DOCS_ROOT = Path(__file__).parent.parent / "vault" / "docs"
DOCS_ROOT.mkdir(parents=True, exist_ok=True)

# ── Gemini — server-side only, never sent to frontend ───────────────────────
GEMINI_API_KEY  = "YOUR_GEMINI_API_KEY_HERE"          # ← set your real key here
GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai"
GEMINI_MODEL    = "gemini-2.5-flash"

vault            = EvidenceVault()
master_agent     = MasterAgent(vault)
search_agent     = SearchAgent(vault)
evidence_agent   = EvidenceAgent(vault)
exception_agent  = ExceptionAgent(vault)
servicenow_agent = ServiceNowAgent()


# ── Models ───────────────────────────────────────────────────────────────────
class LoginRequest(BaseModel):
    username: str
    password: str

class AuditSearchRequest(BaseModel):
    app_id: str
    query: Optional[str] = None
    checklist_id: Optional[str] = None

class ExceptionRequest(BaseModel):
    app_id: str
    checklist_id: str
    exception_type: str
    description: str
    raised_by: str

class AIChatRequest(BaseModel):
    query: str
    app_id: Optional[str] = None
    # Frontend sends doc context so the AI response stays accurate
    doc_context: Optional[str] = None   # pre-formatted string built by frontend

class ServiceNowRequest(BaseModel):
    action: str           # "get_ci" | "search_cis" | "get_incidents" | "get_changes"
    app_id: Optional[str] = None
    params: Optional[dict] = {}


# ── Auth ─────────────────────────────────────────────────────────────────────
@app.post("/api/auth/login")
async def login(req: LoginRequest):
    user = authenticate_user(req.username, req.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_token({"sub": user["username"], "role": user["role"],
                          "name": user["name"], "app_ids": user["app_ids"]})
    return {"token": token, "user": user}


# ── Audit pipeline ────────────────────────────────────────────────────────────
@app.post("/api/audit/search")
async def audit_search(req: AuditSearchRequest,
                       creds: HTTPAuthorizationCredentials = Depends(security)):
    payload = verify_token(creds.credentials)
    if not payload: raise HTTPException(status_code=401)
    return await master_agent.process(
        app_id=req.app_id, query=req.query, checklist_id=req.checklist_id,
        auditor=payload["sub"], search_agent=search_agent, evidence_agent=evidence_agent)

@app.get("/api/audit/exceptions/{app_id}")
async def get_exceptions(app_id: str, creds: HTTPAuthorizationCredentials = Depends(security)):
    verify_token(creds.credentials)
    return {"app_id": app_id, "exceptions": vault.get_exceptions(app_id)}

@app.post("/api/audit/exception")
async def raise_exception(req: ExceptionRequest,
                          creds: HTTPAuthorizationCredentials = Depends(security)):
    payload = verify_token(creds.credentials)
    if not payload: raise HTTPException(status_code=401)
    return await exception_agent.handle(
        app_id=req.app_id, checklist_id=req.checklist_id,
        exception_type=req.exception_type, description=req.description,
        raised_by=req.raised_by, auditor=payload["sub"])


# ── Document upload ───────────────────────────────────────────────────────────
@app.post("/api/docs/upload")
async def upload_document(
    app_id: str = Form(...),
    checklist_id: str = Form(...),
    file: UploadFile = File(...),
    creds: HTTPAuthorizationCredentials = Depends(security),
):
    payload = verify_token(creds.credentials)
    if not payload: raise HTTPException(status_code=401)
    if payload["role"] not in ("bankuser", "admin"):
        raise HTTPException(status_code=403, detail="Only BankUsers or Admins can upload")
    if app_id not in payload["app_ids"] and payload["role"] != "admin":
        raise HTTPException(status_code=403, detail=f"Not authorised for {app_id}")

    dest_dir  = DOCS_ROOT / app_id / checklist_id
    dest_dir.mkdir(parents=True, exist_ok=True)
    doc_id    = f"{uuid.uuid4().hex[:10]}{Path(file.filename).suffix}"
    dest_path = dest_dir / doc_id

    with open(dest_path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    meta = {"doc_id": doc_id, "original_name": file.filename, "app_id": app_id,
            "checklist_id": checklist_id, "uploaded_by": payload["sub"],
            "role": payload["role"], "uploaded_at": datetime.utcnow().isoformat(),
            "size_bytes": os.path.getsize(dest_path)}
    (dest_dir / f"{doc_id}.meta.json").write_text(json.dumps(meta, indent=2))
    logger.info(f"Uploaded: {dest_path}")
    return {"status": "uploaded", "document": meta}


@app.get("/api/docs/list/{app_id}")
async def list_documents(app_id: str, creds: HTTPAuthorizationCredentials = Depends(security)):
    verify_token(creds.credentials)
    app_dir = DOCS_ROOT / app_id
    if not app_dir.exists():
        return {"app_id": app_id, "documents": []}
    docs = [json.loads(f.read_text()) for f in app_dir.rglob("*.meta.json")]
    docs.sort(key=lambda d: d["uploaded_at"], reverse=True)
    return {"app_id": app_id, "documents": docs}


@app.get("/api/docs/download/{app_id}/{checklist_id}/{doc_id}")
async def download_single(app_id: str, checklist_id: str, doc_id: str,
                          creds: HTTPAuthorizationCredentials = Depends(security)):
    verify_token(creds.credentials)
    path = DOCS_ROOT / app_id / checklist_id / doc_id
    if not path.exists():
        raise HTTPException(status_code=404, detail="Document not found")
    # Retrieve original name from meta if available
    meta_path = DOCS_ROOT / app_id / checklist_id / f"{doc_id}.meta.json"
    filename  = doc_id
    if meta_path.exists():
        filename = json.loads(meta_path.read_text()).get("original_name", doc_id)
    return FileResponse(str(path), filename=filename,
                        media_type="application/octet-stream")


# ── Download ALL docs for an app as a ZIP ────────────────────────────────────
@app.get("/api/docs/download-all/{app_id}")
async def download_all_zip(app_id: str,
                           creds: HTTPAuthorizationCredentials = Depends(security)):
    """Stream a ZIP of every uploaded document for the given app."""
    verify_token(creds.credentials)
    app_dir = DOCS_ROOT / app_id
    if not app_dir.exists():
        raise HTTPException(status_code=404, detail=f"No documents found for {app_id}")

    # Gather all non-meta files
    doc_files = [f for f in app_dir.rglob("*") if f.is_file() and not f.name.endswith(".meta.json")]
    if not doc_files:
        raise HTTPException(status_code=404, detail="No documents to download")

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for fpath in doc_files:
            # Try to use the original filename inside the zip
            meta_path = fpath.parent / f"{fpath.name}.meta.json"
            arc_name  = fpath.name
            if meta_path.exists():
                orig = json.loads(meta_path.read_text()).get("original_name", "")
                if orig:
                    # place inside subfolder: APP001/BK003/filename.pdf
                    rel = fpath.relative_to(DOCS_ROOT)
                    arc_name = str(rel.parent / orig)
            zf.write(fpath, arc_name)

    buf.seek(0)
    headers = {"Content-Disposition": f'attachment; filename="{app_id}_documents.zip"'}
    return StreamingResponse(buf, media_type="application/zip", headers=headers)


# ── Delete a single document ──────────────────────────────────────────────────
@app.delete("/api/docs/delete/{app_id}/{checklist_id}/{doc_id}")
async def delete_document(app_id: str, checklist_id: str, doc_id: str,
                          creds: HTTPAuthorizationCredentials = Depends(security)):
    payload = verify_token(creds.credentials)
    if not payload: raise HTTPException(status_code=401)
    if payload["role"] not in ("bankuser", "admin"):
        raise HTTPException(status_code=403, detail="Only BankUsers or Admins can delete")
    if app_id not in payload["app_ids"] and payload["role"] != "admin":
        raise HTTPException(status_code=403, detail=f"Not authorised for {app_id}")

    base = DOCS_ROOT / app_id / checklist_id
    doc_path  = base / doc_id
    meta_path = base / f"{doc_id}.meta.json"

    if not doc_path.exists():
        raise HTTPException(status_code=404, detail="Document not found")

    doc_path.unlink()
    if meta_path.exists():
        meta_path.unlink()

    logger.info(f"Deleted: {doc_path}")
    return {"status": "deleted", "doc_id": doc_id, "app_id": app_id, "checklist_id": checklist_id}


# ── AI Chat — Gemini proxied server-side ──────────────────────────────────────
@app.post("/api/ai/query")
async def ai_query(req: AIChatRequest,
                   creds: HTTPAuthorizationCredentials = Depends(security)):
    import httpx
    payload = verify_token(creds.credentials)
    if not payload: raise HTTPException(status_code=401)

    # Build context from uploaded docs on disk (authoritative source of truth)
    doc_lines = []
    if req.app_id:
        app_dir = DOCS_ROOT / req.app_id
        if app_dir.exists():
            for meta_file in sorted(app_dir.rglob("*.meta.json")):
                m = json.loads(meta_file.read_text())
                doc_lines.append(
                    f"  [{m['checklist_id']}] {m['original_name']} "
                    f"({m['size_bytes']} bytes, uploaded by {m['uploaded_by']} on {m['uploaded_at'][:10]})"
                )

    # Also accept pre-formatted context sent by the frontend (includes in-memory docs)
    extra_ctx = req.doc_context or ""

    system_prompt = f"""You are an expert audit assistant for a banking Audit Evidence Vault.

FIXED 7-ITEM BANK CHECKLIST:
BK001 CMDB Integration (Infrastructure)
BK002 CyberArk Integration (Security)
BK003 Architecture Diagram (Documentation)
BK004 Data Flow Diagram (Documentation)
BK005 OS Baseline Sign-off (Compliance)
BK006 DB Sign-off (Compliance)
BK007 DAM Integration (Security)

APPLICATION: {req.app_id or "Not specified"}

DOCUMENTS ON SERVER DISK:
{chr(10).join(doc_lines) if doc_lines else "  None stored on disk yet."}

{("FRONTEND DOCUMENT CONTEXT (includes in-memory uploads):\n" + extra_ctx) if extra_ctx else ""}

RULES:
- Reference BK001–BK007 IDs in every answer
- Name exact files when user asks to show/list/fetch documents
- State clearly which items are missing (no document uploaded)
- Give exact coverage numbers when asked
- Do NOT invent documents not listed above
- Be concise, factual and structured"""

    url     = f"{GEMINI_BASE_URL.rstrip('/')}/chat/completions"
    headers = {"Authorization": f"Bearer {GEMINI_API_KEY}", "Content-Type": "application/json"}
    body    = {
        "model":      GEMINI_MODEL,
        "max_tokens": 1024,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": req.query},
        ],
    }

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(url, headers=headers, json=body)
            resp.raise_for_status()
            data   = resp.json()
            answer = data["choices"][0]["message"]["content"]
            return {"answer": answer, "model": GEMINI_MODEL}
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=502, detail=f"Gemini error {e.response.status_code}: {e.response.text}")
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"AI call failed: {e}")


# ── ServiceNow Spoof Agent ────────────────────────────────────────────────────
@app.post("/api/servicenow/query")
async def servicenow_query(req: ServiceNowRequest,
                           creds: HTTPAuthorizationCredentials = Depends(security)):
    """
    Proxy to the ServiceNow agent.
    Actions: get_ci | search_cis | get_incidents | get_changes | get_cmdb_summary
    """
    payload = verify_token(creds.credentials)
    if not payload: raise HTTPException(status_code=401)
    result = await servicenow_agent.execute(
        action=req.action, app_id=req.app_id, params=req.params or {}
    )
    return result

@app.get("/api/servicenow/ci/{app_id}")
async def get_ci_for_app(app_id: str,
                         creds: HTTPAuthorizationCredentials = Depends(security)):
    """Convenience endpoint: fetch all CIs for an app from ServiceNow."""
    verify_token(creds.credentials)
    return await servicenow_agent.execute(action="get_cmdb_summary", app_id=app_id, params={})


@app.get("/api/health")
async def health():
    return {"status": "ok", "timestamp": datetime.utcnow().isoformat(), "version": "4.0.0"}
