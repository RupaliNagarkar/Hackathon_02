"""
ServiceNow Spoof Agent
----------------------
Simulates a real ServiceNow integration via spoofed REST responses.
In production: replace _call_servicenow() with real HTTP calls to your
ServiceNow instance at https://<instance>.service-now.com/api/now/...

Supported actions:
  get_ci            – fetch a single Configuration Item by sys_id or name
  search_cis        – search CIs by application
  get_incidents     – open incidents linked to an application
  get_changes       – change requests for an application
  get_cmdb_summary  – full CMDB summary for an app (used by BK001 evidence)
"""

import asyncio
import logging
import random
import uuid
from datetime import datetime, timedelta
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# ── Fake ServiceNow instance config (would be env vars in production) ─────────
SN_INSTANCE   = "bankdemo.service-now.com"
SN_BASE_URL   = f"https://{SN_INSTANCE}/api/now"
SN_AUTH_USER  = "svc_audit_ro"          # read-only service account
SN_AUTH_TOKEN = "SPOOF_TOKEN_NO_REAL_CALL"

# ── Static spoof data store ────────────────────────────────────────────────────
_SPOOF_CIS = {
    "APP001": [
        {"sys_id": "ci001a", "name": "APP001-WEB-01",   "class": "cmdb_ci_app_server",
         "ip": "10.10.1.11", "os": "RHEL 8.7", "env": "Production",
         "status": "In Service", "owner": "app001-team@bank.com", "last_discovered": "2024-03-10"},
        {"sys_id": "ci001b", "name": "APP001-DB-01",    "class": "cmdb_ci_database",
         "ip": "10.10.1.12", "os": "Oracle Linux 8", "env": "Production",
         "status": "In Service", "owner": "dba-team@bank.com",     "last_discovered": "2024-03-10"},
        {"sys_id": "ci001c", "name": "APP001-LB-01",    "class": "cmdb_ci_lb_server",
         "ip": "10.10.1.10", "os": "F5 BIG-IP",      "env": "Production",
         "status": "In Service", "owner": "network-team@bank.com", "last_discovered": "2024-03-09"},
        {"sys_id": "ci001d", "name": "APP001-WEB-01-DR","class": "cmdb_ci_app_server",
         "ip": "10.20.1.11", "os": "RHEL 8.7",        "env": "DR",
         "status": "In Service", "owner": "app001-team@bank.com",  "last_discovered": "2024-03-10"},
    ],
    "APP002": [
        {"sys_id": "ci002a", "name": "APP002-APP-01",   "class": "cmdb_ci_app_server",
         "ip": "10.10.2.11", "os": "Windows Server 2022","env": "Production",
         "status": "In Service", "owner": "app002-team@bank.com", "last_discovered": "2024-03-08"},
        {"sys_id": "ci002b", "name": "APP002-DB-01",    "class": "cmdb_ci_database",
         "ip": "10.10.2.12", "os": "SQL Server 2019",  "env": "Production",
         "status": "In Service", "owner": "dba-team@bank.com",    "last_discovered": "2024-03-08"},
    ],
    "APP003": [
        {"sys_id": "ci003a", "name": "APP003-API-01",   "class": "cmdb_ci_app_server",
         "ip": "10.10.3.11", "os": "Ubuntu 22.04",     "env": "Production",
         "status": "In Service", "owner": "app003-team@bank.com", "last_discovered": "2024-03-07"},
        {"sys_id": "ci003b", "name": "APP003-CACHE-01", "class": "cmdb_ci_app_server",
         "ip": "10.10.3.13", "os": "Ubuntu 22.04",     "env": "Production",
         "status": "In Service", "owner": "app003-team@bank.com", "last_discovered": "2024-03-07"},
    ],
}

_SPOOF_INCIDENTS = {
    "APP001": [
        {"number": "INC0012301", "short_description": "APP001 login timeout spike",
         "priority": "2 - High", "state": "In Progress", "assigned_to": "L2 Support",
         "opened_at": "2024-03-05", "category": "Application"},
        {"number": "INC0011887", "short_description": "APP001-DB-01 tablespace alert",
         "priority": "3 - Moderate", "state": "Resolved", "assigned_to": "DBA Team",
         "opened_at": "2024-02-28", "category": "Database"},
    ],
    "APP002": [
        {"number": "INC0012450", "short_description": "APP002 authentication latency",
         "priority": "3 - Moderate", "state": "Open", "assigned_to": "App Support",
         "opened_at": "2024-03-09", "category": "Application"},
    ],
    "APP003": [],
}

_SPOOF_CHANGES = {
    "APP001": [
        {"number": "CHG0003211", "short_description": "OS patch RHEL 8.7 -> 8.8 on APP001-WEB-01",
         "type": "Normal", "state": "Implement", "risk": "Low",
         "scheduled_start": "2024-03-20", "cab_approved": True, "implementer": "infra-team@bank.com"},
    ],
    "APP002": [
        {"number": "CHG0003198", "short_description": "SQL Server CU update APP002-DB-01",
         "type": "Normal", "state": "Review", "risk": "Medium",
         "scheduled_start": "2024-03-22", "cab_approved": False, "implementer": "dba-team@bank.com"},
    ],
    "APP003": [],
}


class ServiceNowAgent:
    """
    Agent that talks to ServiceNow (spoofed).
    Mimics real ServiceNow Table API response structure.
    """
    name = "ServiceNowAgent"

    async def execute(self, action: str, app_id: Optional[str], params: Dict) -> Dict[str, Any]:
        logger.info(f"[{self.name}] action={action} app_id={app_id}")

        # Simulate network latency
        await asyncio.sleep(0.15)

        dispatch = {
            "get_ci":           self._get_ci,
            "search_cis":       self._search_cis,
            "get_incidents":    self._get_incidents,
            "get_changes":      self._get_changes,
            "get_cmdb_summary": self._get_cmdb_summary,
        }

        handler = dispatch.get(action)
        if not handler:
            return {"success": False, "error": f"Unknown action: {action}",
                    "available_actions": list(dispatch.keys())}

        return await handler(app_id=app_id, params=params)

    # ── Individual action handlers ────────────────────────────────────────────

    async def _get_ci(self, app_id: Optional[str], params: Dict) -> Dict:
        """Fetch a single CI by sys_id or name."""
        cis = _SPOOF_CIS.get(app_id, [])
        target = params.get("sys_id") or params.get("name", "")
        match  = next((c for c in cis if c["sys_id"] == target or c["name"] == target), None)
        if not match:
            return {"success": False, "error": f"CI '{target}' not found for {app_id}"}
        return {
            "success": True,
            "source":  f"ServiceNow CMDB ({SN_INSTANCE})",
            "endpoint": f"{SN_BASE_URL}/table/cmdb_ci?sysparm_query=name={target}",
            "retrieved_at": datetime.utcnow().isoformat(),
            "result": match,
        }

    async def _search_cis(self, app_id: Optional[str], params: Dict) -> Dict:
        """List all CIs associated with an application."""
        cis = _SPOOF_CIS.get(app_id, [])
        return {
            "success":     True,
            "source":      f"ServiceNow CMDB ({SN_INSTANCE})",
            "endpoint":    f"{SN_BASE_URL}/table/cmdb_ci_appl?sysparm_query=name={app_id}",
            "retrieved_at": datetime.utcnow().isoformat(),
            "app_id":      app_id,
            "total":       len(cis),
            "result":      cis,
        }

    async def _get_incidents(self, app_id: Optional[str], params: Dict) -> Dict:
        """Fetch open/recent incidents linked to an application."""
        incidents = _SPOOF_INCIDENTS.get(app_id, [])
        status_filter = params.get("state")
        if status_filter:
            incidents = [i for i in incidents if status_filter.lower() in i["state"].lower()]
        return {
            "success":     True,
            "source":      f"ServiceNow ITSM ({SN_INSTANCE})",
            "endpoint":    f"{SN_BASE_URL}/table/incident?sysparm_query=cmdb_ci.name={app_id}",
            "retrieved_at": datetime.utcnow().isoformat(),
            "app_id":      app_id,
            "total":       len(incidents),
            "result":      incidents,
        }

    async def _get_changes(self, app_id: Optional[str], params: Dict) -> Dict:
        """Fetch change requests related to an application."""
        changes = _SPOOF_CHANGES.get(app_id, [])
        return {
            "success":     True,
            "source":      f"ServiceNow Change Management ({SN_INSTANCE})",
            "endpoint":    f"{SN_BASE_URL}/table/change_request?sysparm_query=cmdb_ci.name={app_id}",
            "retrieved_at": datetime.utcnow().isoformat(),
            "app_id":      app_id,
            "total":       len(changes),
            "result":      changes,
        }

    async def _get_cmdb_summary(self, app_id: Optional[str], params: Dict) -> Dict:
        """
        Full CMDB summary — used as evidence for BK001 (CMDB Integration).
        Returns CIs, open incidents, pending changes, and a health score.
        """
        cis        = _SPOOF_CIS.get(app_id, [])
        incidents  = _SPOOF_INCIDENTS.get(app_id, [])
        changes    = _SPOOF_CHANGES.get(app_id, [])
        open_inc   = [i for i in incidents if i["state"] not in ("Resolved", "Closed")]
        high_inc   = [i for i in open_inc   if "High" in i.get("priority", "")]
        sync_date  = (datetime.utcnow() - timedelta(hours=random.randint(1, 12))).isoformat()

        ci_classes  = list({c["class"] for c in cis})
        envs        = list({c["env"]   for c in cis})
        health      = "GREEN" if not high_inc else ("AMBER" if len(high_inc) < 2 else "RED")

        return {
            "success":     True,
            "source":      f"ServiceNow CMDB ({SN_INSTANCE})",
            "action":      "get_cmdb_summary",
            "retrieved_at": datetime.utcnow().isoformat(),
            "app_id":      app_id,
            "summary": {
                "total_cis":           len(cis),
                "ci_classes":          ci_classes,
                "environments":        envs,
                "last_discovery_sync": sync_date,
                "open_incidents":      len(open_inc),
                "high_priority_incidents": len(high_inc),
                "pending_changes":     len(changes),
                "cmdb_health":         health,
                "integration_status":  "Active",
                "servicenow_instance": SN_INSTANCE,
            },
            "configuration_items": cis,
            "open_incidents":  open_inc,
            "pending_changes": changes,
        }
